# oat-pw2-crud-estoque

Aluno

*Ismael de Sousa Araujo

