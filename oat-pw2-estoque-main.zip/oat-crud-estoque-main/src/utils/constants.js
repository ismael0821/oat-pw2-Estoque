const security = {
    secret: '12345678',
    iss: 'estoque-api',
    expires: '2h'
}

module.exports = {
    security
}